import os
from supabase import create_client, Client
from dotenv import load_dotenv

load_dotenv()

SUPABASE_URL = os.environ.get("VITE_SUPABASE_URL", "https://ptochsyoyatsydfysacc.supabase.co")
SUPABASE_KEY = os.environ.get("VITE_SUPABASE_ANON_KEY", "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InB0b2Noc3lveWF0c3lkZnlzYWNjIiwicm9sZSI6ImFub24iLCJpYXQiOjE3Njg4NDM0MzUsImV4cCI6MjA4NDQxOTQzNX0.7VKER8NpJz5F9l0TOd6AWTg5U8f2IyXfcrIXCE0KwkQ")

_supabase_client: Client = None

class RHTableWrapper:
    def __init__(self, client: Client):
        self._client = client
        
    def table(self, table_name: str):
        if not table_name.startswith("rh_"):
            table_name = f"rh_{table_name}"
        return self._client.table(table_name)

def get_supabase():
    global _supabase_client
    if _supabase_client is None:
        _supabase_client = create_client(SUPABASE_URL, SUPABASE_KEY)
    return RHTableWrapper(_supabase_client)
